﻿using FutureValueEmpty.Models;
using Microsoft.AspNetCore.Mvc;

namespace FutureValueEmpty.Controllers
{
    public class HomeController : Controller
    {
        
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(FutureValueModel model)
        {
            if (ModelState.IsValid)
            {
                model.FutureValue = model.CalculateFutureValue();
            }

            return View(model);
        }
    }
}