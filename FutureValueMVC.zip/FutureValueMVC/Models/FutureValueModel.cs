﻿using System.ComponentModel.DataAnnotations;

namespace FutureValueMVC.Models
{
    public class FutureValueModel
    {
        [Required]
        [Range(1, 10000)]
        public decimal MonthlyInvestment { get; set; }

        [Required]
        [Range(0.001, 1)]
        public decimal MonthlyInterestRate { get; set; }

        [Required]
        [Range(1, 480)]
        public int Months { get; set; }

        public decimal FutureValue { get; set; }

        public decimal CalculateFutureValue()
        {
            decimal futureValue = 0;

            for (int i = 0; i < Months; i++)
            {
                futureValue = (futureValue + MonthlyInvestment) * (1 + MonthlyInterestRate);
            }

            return futureValue;
        }
    }
}